import pandas as pd
from datetime import datetime

class DataProcessorAgent:
    def __init__(self, file_path, columns_to_process):
        self.file_path = file_path
        self.columns_to_process = columns_to_process
        self.data = None

    def load_data(self):
        """Loads the CSV data."""
        try:
            self.data = pd.read_csv(self.file_path)
            print("Data loaded successfully.")
        except Exception as e:
            print(f"Error loading data: {e}")

    def clean_data(self):
        """Cleans the data."""
        if self.data is not None:
            # Remove any rows where 'AssignedTasks' is empty
            self.data.dropna(subset=['AssignedTasks'], inplace=True)

            # Convert 'LastActivity' to datetime
            self.data['LastActivity'] = pd.to_datetime(self.data['LastActivity'], errors='coerce')

            # Remove any rows with invalid dates
            self.data.dropna(subset=['LastActivity'], inplace=True)
            print("Data cleaned successfully.")
        else:
            print("Data not loaded. Please load data first.")

    def enrich_data(self):
        """Enriches the data with additional columns."""
        if self.data is not None:
            # Count the number of tasks assigned to each agent
            self.data['TaskCount'] = self.data['AssignedTasks'].apply(lambda x: len(x.split(',')))

            # Flag for agents that are 'Active' or 'Inactive'
            self.data['IsActive'] = self.data['Status'].apply(lambda x: 1 if x == 'Active' else 0)

            print("Data enriched successfully.")
        else:
            print("Data not loaded. Please load data first.")

    def save_data(self, output_path):
        """Saves the processed data to a new CSV file."""
        if self.data is not None:
            self.data.to_csv(output_path, index=False)
            print(f"Data saved to {output_path}.")
        else:
            print("No processed data to save.")

    def process(self):
        """Runs the complete process of loading, cleaning, enriching, and saving."""
        self.load_data()
        self.clean_data()
        self.enrich_data()

