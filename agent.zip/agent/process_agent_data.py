import sys
import os
import pandas as pd

# Add the directory containing 'agents' to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ''))

# Import the DataProcessorAgent class
from data_processor import DataProcessorAgent

# Define the CSV file path and columns to process
file_path = 'agents_data.csv'  # Use relative path to CSV file
columns_to_process = ['AgentID', 'AgentName', 'Status', 'LastActivity', 'AssignedTasks']

# Create a DataProcessorAgent instance
processor = DataProcessorAgent(file_path, columns_to_process)

# Process the data
processor.process()

# Save the processed data
processor.save_data('processed_agents_data.csv')  # Output file in the current directory

