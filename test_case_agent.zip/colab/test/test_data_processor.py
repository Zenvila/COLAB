# test/test_data_processor.py

import unittest
from agent.data_processor import DataProcessorAgent  # Fixed import path

class TestDataProcessorAgent(unittest.TestCase):
    
    def setUp(self):
        self.agent = DataProcessorAgent()
    
    def test_clean_data(self):
        result = self.agent.clean_data(" Hello World ")
        self.assertEqual(result, "hello world")
    
    def test_enrich_data(self):
        result = self.agent.enrich_data("test data")
        self.assertEqual(result, "test data enriched")
    
    def test_standardize_data(self):
        result = self.agent.standardize_data("some data to standardize")
        self.assertEqual(result, "some_data_to_standardize")
    
    def test_process_data(self):
        result = self.agent.process_data(" Some raw data ")
        self.assertEqual(result, "some_raw_data_enriched")

if __name__ == "__main__":
    unittest.main()
